import React from "react";
import "./footer.css";
import { Link } from "react-router";


const Footer = () => {
  return (
    <>
        <h1>Footer</h1>
    </>
  );
};
export default Footer;