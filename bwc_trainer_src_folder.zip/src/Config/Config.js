const BASE_API_URL = "http://54.185.32.148/api";

export default BASE_API_URL;

export  const MEDIA_BASE_URL = "http://54.185.32.148/";